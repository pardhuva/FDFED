const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
const port = 3000;

// Middleware
app.use(cors()); // Enable CORS for frontend AJAX requests
app.use(express.json()); // Parse JSON bodies from AJAX POST requests
app.use(express.static('public')); // Serve static files (e.g., product.html)

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/productCatalog', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Product schema
const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    category: { type: String, required: true },
    mfgDate: { type: String, required: true },
    onSale: { type: Boolean, default: false }
});

const Product = mongoose.model('Product', productSchema);

// GET endpoint for fetching products (called via AJAX)
app.get('/api/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products); // Send JSON response to frontend AJAX request
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch products' });
    }
});

// POST endpoint for adding products (called via AJAX)
app.post('/api/products', async (req, res) => {
    const { name, price, category, mfgDate, onSale } = req.body;
    if (!name || !price || !category || !mfgDate) {
        return res.status(400).json({ error: 'All fields are required' });
    }
    try {
        const newProduct = new Product({
            name,
            price: parseFloat(price),
            category,
            mfgDate,
            onSale: onSale === 'true' || onSale === true
        });
        await newProduct.save();
        res.status(201).json(newProduct); // Send JSON response to frontend AJAX request
    } catch (error) {
        res.status(500).json({ error: 'Failed to add product' });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});